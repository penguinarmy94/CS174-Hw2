Members (name, id #):

Luis Otero        008165586
Jorge Aguiniga    008214700
